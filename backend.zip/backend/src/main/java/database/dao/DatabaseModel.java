package database.dao;

import org.springframework.context.ApplicationContext;

public interface DatabaseModel {

	public void run();
	public ApplicationContext getContext();
}
