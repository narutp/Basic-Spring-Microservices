# "Hello World" Micro Service

Language: Java

Framework: Spring

Tool: STS

## How to run

Run it on Spring Tool Suite (STS) is the easiest way to go

download and install STS

https://spring.io

Open STS and go to

> File -> Import -> General -> Existing Projects into work space -> [Select the directory and there it is :D ]

before running it's better to fix the port in "run configuration", for example 8085 

then open this link in the web browser

> http://localhost:8085/hello?name=whatever

there it is :)

# More detail 

Micro service and Hello World with JAVA Spring Framework

http://www.slideshare.net/PankamolSrikaew/micro-service-56062328

# Extended project with MongoDB

Oh~ I'm so glad to present this one

https://github.com/AimePGM/HelloWorldJavaMicroServiceWithMongoDB

hope it help :)

Thank you
